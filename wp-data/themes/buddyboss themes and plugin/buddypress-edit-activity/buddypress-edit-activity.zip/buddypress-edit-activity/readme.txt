=== BuddyPress Edit Activity ===
Contributors: buddyboss
Donate link: http://www.buddyboss.com/donate/
Tags: buddypress, social networking, activity, profiles, messaging, friends, groups, forums, notifications, settings, social, community, networks, networking
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 1.0.5
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

BuddyPress Edit Activity allows your members to edit their activity posts on the front-end of your BuddyPress-powered site.

== Description ==

Let your BuddyPress members edit their activity posts and replies on the front-end of the site. You can even set a time limit for how long activity posts should remain editable.

Just activate the plugin, and every activity post and reply will become editable, styled automatically by BuddyPress to fit with your theme.

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'BuddyPress Edit Activity'
3. Activate BuddyPress Edit Activity from your Plugins page.

= From WordPress.org =

1. Download BuddyPress Edit Activity.
2. Upload the 'buddypress-edit-activity' directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, etc...)
3. Activate BuddyPress Edit Activity from your Plugins page.

= Configuration =

1. Visit 'Settings > BP Edit Activity' to configure plugin options.
2. Adjust the CSS of your theme as needed, to make everything pretty.

== Frequently Asked Questions ==

= Where can I find documentation and tutorials? =

For help setting up and configuring any BuddyBoss plugin please refer to our [tutorials](http://www.buddyboss.com/tutorials/).

= Does this plugin require BuddyPress? =

Yes, it requires [BuddyPress](https://wordpress.org/plugins/buddypress/) to work.

= Will it work with my theme? =

Yes, BuddyPress Edit Activity should work with any theme, and will adopt your BuddyPress styling for activity editing. It may require some styling to make it match perfectly, depending on your theme.

= Where can I request customizations? =

For BuddyPress customizations, submit your request at [BuddyBoss](http://www.buddyboss.com/buddypress-developers/).

== Screenshots ==

1. **Post Editing** - Editing an activity post from the front-end
2. **Admin** - Configuring plugin options

== Changelog ==

= 1.0.5 =
* Added French translation files - credits to Jean-Pierre Michaud
* Added Italian translation files - credits to Massimiliano Napoli
* Fixed translation string for "Edit" text
* Added 100% width for edit textarea

= 1.0.4 =
* Multisite compatibility, no longer requires network activation
* Editing activity now shows a "Cancel" button
* Fix for correctly rendering utf-8 characters (Greek, Arabic, etc.)
* Modified script selectors to allow for editing other activity types

= 1.0.3 =
* Remove wrapping <p> tag in edit activity content
* Added Persian translation files - credits to Mahdiar Amani

= 1.0.2 =
* Added Settings option: "Exclude admins from time limit."

= 1.0.1 =
* Updated documentation

= 1.0.0 =
* Initial public release

= 0.0.2 =
* Bug fixes

= 0.0.1 =
* Initial beta version
