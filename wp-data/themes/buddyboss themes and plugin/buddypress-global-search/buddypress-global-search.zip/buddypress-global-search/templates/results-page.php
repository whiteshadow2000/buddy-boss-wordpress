<?php
/**
 * the template file to display search result page having buddypress container 
 * dont make changes to this file,
 * instead create a folder 'buddyboss-global-search' inside your theme, copy this file over there, and make changes there
 */
?>

<div id="buddypress">

	<?php buddyboss_global_search_load_template("results-page-content"); ?>

</div>