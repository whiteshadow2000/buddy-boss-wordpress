<div class="bboss_ajax_search_item bboss_ajax_search_item_topic">
	<a href="<?php echo esc_url(add_query_arg( array( 'no_frame' => '1' ), bbp_get_topic_permalink(get_the_ID()) )); ?>">
		<div class="item">
			<div class="item-title"><?php echo buddyboss_global_search_reply_intro( 30 ); ?></div>
		</div>
	</a>
</div>