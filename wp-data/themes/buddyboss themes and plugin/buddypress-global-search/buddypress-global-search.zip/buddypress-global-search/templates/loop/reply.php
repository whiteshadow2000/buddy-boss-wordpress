<li class="bboss_search_item bboss_search_item_reply">
	<a href="<?php bbp_reply_url(get_the_ID()); ?>">
		<div class="item">
			<div class="item-desc"><?php echo buddyboss_global_search_reply_intro( 100 );?></div>
		</div>
	</a>
</li>