<li class="bboss_search_item bboss_search_item_topic">
	<div class="item">
		<div class="item-title"><a href="<?php bbp_topic_permalink(get_the_ID()); ?>"><?php bbp_topic_title(get_the_ID()); ?></a></div>
		<div class="item-desc"><?php echo buddyboss_global_search_reply_intro( 100 );?></a>
	</div>
</li>