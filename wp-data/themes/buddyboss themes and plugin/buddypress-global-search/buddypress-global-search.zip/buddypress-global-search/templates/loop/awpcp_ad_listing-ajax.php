<div class="bboss_ajax_search_item bboss_ajax_search_item_post">
	<a href="$url_showad">
		<div class="item">
			<div class="item-title">$ad_title</div>
			<div class="item-desc">$addetailssummary</div>
		</div>
	</a>
</div>