/*--------------------------------------------------------------
BUDDYPRESS TEMPLATE INFO
--------------------------------------------------------------*/
These templates are overriding default templates from BuddyPress Groups Extras