## Add redux in your project:

Run following command on project root:

git subtree add --prefix=buddyboss-inc/buddyboss-framework/admin --squash git@github.com:ReduxFramework/redux-framework.git master

## Update redux in your project:

Run following command on project root:

git subtree pull --prefix=buddyboss-inc/buddyboss-framework/admin --squash git@github.com:ReduxFramework/redux-framework.git master